import React from "react";

const Main = () => {
  return (
    <div className="mainText">
      <h2> Klick on a Book to see the details! </h2>{" "}
    </div>
  );
};

export default Main;
